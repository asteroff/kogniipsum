import random

number = random.randint(1,30)
number2 = random.randint(20,100)
#temp = open("gpt2_generated/gpt2_gentext%s.txt" % number, 'r')
#l = ''.join(map(str, temp))



from itertools import islice

# define the name of the file to read from
filename = ("gpt2_generated/gpt2_gentext%s.txt" % number)

# define the number of lines to read
number_of_lines =number2

with open(filename, 'r') as input_file:
    lines_cache = islice(input_file, number_of_lines)

    for current_line in lines_cache:
        print (current_line)