from flask import Flask, render_template, json, request, url_for
import random
app = Flask(__name__)


@app.route('/')

def strona():
    return render_template("strona.html")



@app.route('/foo', methods = ['POST', 'GET'])
def foo():
    if request.method == "POST":
        number = random.randint(1, 30)
        #kiedy będzie formularz seed do wypełnienia
        #seed = request.form['seed']
        temp = open("gpt2_generated/gpt2_gentext%s.txt" % number, 'r')
        l = ' '.join(map(str, temp))

        return render_template("generate.html", output=l)



if __name__ == '__main__':
    app.run(debug=True)
